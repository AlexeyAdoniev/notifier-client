import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { setWallets, setMoney } from "../store/appSlice";

export const withSettingsEffects = (Wrapped) => (props) => {
  const dispatch = useDispatch();

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`http://localhost:3100/getSettings`);

        const {
          result: { wallets, thresholdMoney },
          ok,
        } = await res.json();

        if (ok) {
          dispatch(
            setWallets({
              wallets,
            })
          );

          dispatch(
            setMoney({
              thresholdMoney,
            })
          );
        }
      } catch (e) {
        console.log(e);
      }
    })();
  }, []);

  return <Wrapped {...props} />;
};
